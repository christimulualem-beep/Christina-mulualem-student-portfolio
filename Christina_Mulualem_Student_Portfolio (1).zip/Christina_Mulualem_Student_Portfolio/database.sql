CREATE DATABASE IF NOT EXISTS christina_portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE christina_portfolio;

CREATE TABLE IF NOT EXISTS profile (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 grade_level VARCHAR(40) NOT NULL,
 school VARCHAR(150) NOT NULL,
 career_goal VARCHAR(150) NOT NULL,
 introduction TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS skills (
 id INT AUTO_INCREMENT PRIMARY KEY,
 skill_name VARCHAR(100) NOT NULL,
 description VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(150) NOT NULL,
 description TEXT NOT NULL,
 learning TEXT NOT NULL,
 project_date DATE NULL
);
CREATE TABLE IF NOT EXISTS achievements (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(150) NOT NULL,
 description TEXT NOT NULL,
 achievement_date DATE NULL
);

INSERT INTO profile (full_name,grade_level,school,career_goal,introduction)
SELECT 'Christina Mulualem','Grade 12','Kings Academy','Computer Engineering',
'I am a Grade 12 student who enjoys learning, solving problems, and exploring technology.'
WHERE NOT EXISTS (SELECT 1 FROM profile);

INSERT INTO skills (skill_name,description)
SELECT 'Problem-solving','Break challenges into smaller steps and look for solutions.'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE skill_name='Problem-solving');
INSERT INTO skills (skill_name,description)
SELECT 'Communication','Share ideas clearly and listen to different perspectives.'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE skill_name='Communication');
INSERT INTO skills (skill_name,description)
SELECT 'Teamwork','Contribute, cooperate, and learn with others.'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE skill_name='Teamwork');
INSERT INTO skills (skill_name,description)
SELECT 'Creativity','Explore new approaches and think beyond the obvious.'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE skill_name='Creativity');
INSERT INTO skills (skill_name,description)
SELECT 'Digital literacy','Use digital tools responsibly to learn and create.'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE skill_name='Digital literacy');
