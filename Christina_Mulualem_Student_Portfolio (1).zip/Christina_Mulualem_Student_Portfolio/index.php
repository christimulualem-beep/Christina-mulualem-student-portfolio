<?php
require_once __DIR__ . '/config.php';
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$p = $pdo->query('SELECT * FROM profile ORDER BY id LIMIT 1')->fetch();
$skills = $pdo->query('SELECT * FROM skills ORDER BY id')->fetchAll();
$projects = $pdo->query('SELECT * FROM projects ORDER BY id DESC')->fetchAll();
$awards = $pdo->query('SELECT * FROM achievements ORDER BY id DESC')->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($p['full_name'])?> | Student Portfolio</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header><nav><a class="brand" href="#">CM.</a><div>
<a href="#about">About</a><a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#goals">Goals</a>
</div></nav></header>
<main>
<section class="hero"><p><?=e($p['school'])?> · <?=e($p['grade_level'])?></p>
<h1>Hello, I'm <span><?=e($p['full_name'])?></span></h1>
<h2>Aspiring <?=e($p['career_goal'])?> Engineer</h2>
<p><?=e($p['introduction'])?></p><a class="btn" href="#about">Explore my portfolio</a></section>
<section id="about"><p class="tag">ABOUT ME</p><h2>My learning journey</h2>
<p>I am a Grade 12 student at Kings Academy with an interest in Computer Engineering. I enjoy learning, solving problems, and exploring how technology can help people.</p></section>
<section id="skills" class="soft"><p class="tag">WHAT I AM DEVELOPING</p><h2>Skills &amp; strengths</h2><div class="grid">
<?php foreach($skills as $s): ?><article><h3><?=e($s['skill_name'])?></h3><p><?=e($s['description'])?></p></article><?php endforeach; ?>
</div></section>
<section id="projects"><p class="tag">LEARNING BY DOING</p><h2>Projects</h2><div class="grid">
<?php if(!$projects): ?><article><p>My projects will appear here as I add my own work and learning experiences.</p></article><?php endif; ?>
<?php foreach($projects as $x): ?><article><h3><?=e($x['title'])?></h3><p><?=e($x['description'])?></p><p><b>What I learned:</b> <?=e($x['learning'])?></p></article><?php endforeach; ?>
</div></section>
<section class="soft"><p class="tag">MILESTONES</p><h2>Achievements</h2><div class="grid">
<?php if(!$awards): ?><article><p>Certificates and achievements can be added here when available.</p></article><?php endif; ?>
<?php foreach($awards as $a): ?><article><h3><?=e($a['title'])?></h3><p><?=e($a['description'])?></p></article><?php endforeach; ?>
</div></section>
<section id="goals"><p class="tag">LOOKING AHEAD</p><h2>My future goal</h2>
<p>My goal is to complete Grade 12, continue strengthening my mathematics and science skills, learn more about programming and technology, and pursue Computer Engineering.</p></section>
</main>
<footer>Christina Mulualem · Grade 12 · Kings Academy<br>Learn with purpose. Create with courage. Keep growing.</footer>
</body></html>